-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 07, 2021 at 09:57 AM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 8.0.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_groupin`
--

-- --------------------------------------------------------

--
-- Table structure for table `dosen`
--

CREATE TABLE `dosen` (
  `niy` int(15) NOT NULL,
  `nama_dosen` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `dosen`
--

INSERT INTO `dosen` (`niy`, `nama_dosen`, `email`) VALUES
(918278721, 'dwi normawati', 'saerosuta@gmail.com'),
(933373848, 'rochamah', 'muhamad.dhabit123@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `link_matkul`
--

CREATE TABLE `link_matkul` (
  `id_link` int(3) NOT NULL,
  `nama_matkul` varchar(50) NOT NULL,
  `nama_dosen` varchar(50) NOT NULL,
  `link_wa` varchar(250) NOT NULL,
  `link_clashroom` varchar(250) NOT NULL,
  `niy` int(15) NOT NULL,
  `id_matkul` int(5) NOT NULL,
  `kelas` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `link_praktikum`
--

CREATE TABLE `link_praktikum` (
  `id_link` int(3) NOT NULL,
  `nama_praktikum` varchar(150) NOT NULL,
  `link_wa` varchar(150) NOT NULL,
  `link_clashroom` varchar(150) NOT NULL,
  `id_praktikum` int(5) NOT NULL,
  `slot` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `matakuliah`
--

CREATE TABLE `matakuliah` (
  `id_matkul` int(5) NOT NULL,
  `nama_matkul` varchar(50) NOT NULL,
  `sks` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `matakuliah`
--

INSERT INTO `matakuliah` (`id_matkul`, `nama_matkul`, `sks`) VALUES
(6, 'Algoritma Pemrograman', 4),
(7, 'Kalkulus', 2);

-- --------------------------------------------------------

--
-- Table structure for table `praktikum`
--

CREATE TABLE `praktikum` (
  `id_praktikum` int(5) NOT NULL,
  `nama_praktikum` varchar(50) NOT NULL,
  `sks` int(1) NOT NULL,
  `slot` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id_user` int(3) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `role_id` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id_user`, `username`, `password`, `role_id`) VALUES
(1, 'admin', 'admin', 'admin'),
(4, 'mhs', 'mhs', 'mahasiswa');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `dosen`
--
ALTER TABLE `dosen`
  ADD PRIMARY KEY (`niy`);

--
-- Indexes for table `link_matkul`
--
ALTER TABLE `link_matkul`
  ADD PRIMARY KEY (`id_link`),
  ADD KEY `niy` (`niy`),
  ADD KEY `id_matkul` (`id_matkul`) USING BTREE;

--
-- Indexes for table `link_praktikum`
--
ALTER TABLE `link_praktikum`
  ADD PRIMARY KEY (`id_link`),
  ADD KEY `id_praktikum` (`id_praktikum`);

--
-- Indexes for table `matakuliah`
--
ALTER TABLE `matakuliah`
  ADD PRIMARY KEY (`id_matkul`);

--
-- Indexes for table `praktikum`
--
ALTER TABLE `praktikum`
  ADD PRIMARY KEY (`id_praktikum`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `link_matkul`
--
ALTER TABLE `link_matkul`
  MODIFY `id_link` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `link_praktikum`
--
ALTER TABLE `link_praktikum`
  MODIFY `id_link` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `matakuliah`
--
ALTER TABLE `matakuliah`
  MODIFY `id_matkul` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `praktikum`
--
ALTER TABLE `praktikum`
  MODIFY `id_praktikum` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id_user` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `link_matkul`
--
ALTER TABLE `link_matkul`
  ADD CONSTRAINT `link_matkul_ibfk_3` FOREIGN KEY (`niy`) REFERENCES `dosen` (`niy`),
  ADD CONSTRAINT `link_matkul_ibfk_4` FOREIGN KEY (`id_matkul`) REFERENCES `matakuliah` (`id_matkul`);

--
-- Constraints for table `link_praktikum`
--
ALTER TABLE `link_praktikum`
  ADD CONSTRAINT `link_praktikum_ibfk_1` FOREIGN KEY (`id_praktikum`) REFERENCES `praktikum` (`id_praktikum`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
