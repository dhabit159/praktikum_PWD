<?php
// define('BASEPATH') or exit('No direct script access allowed');

class Login_model extends CI_Model
{
    public function index($username, $password)
    {
        $user = $this->db->query('SELECT * user WHERE username = $username && password = $password');
        return $user->row();
        if ($user) {
            $data = array(
                'username'  => $username,
                'password'  => $password,
            );

            $this->session->set_userdata($data);
        }
    }
}
