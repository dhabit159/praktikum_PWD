<?php

class User_model extends CI_Model
{
    public function login($email, $password)
    {
        $this->db->where('email', $email and 'password', $password);
        if ($query = $this->db->get('user')) {
            return $query->row();
        } else {
            return false;
        }
    }

    public function registrasi_($data)
    {
        $this->db->insert('user', $data);
    }
}
