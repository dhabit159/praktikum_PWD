<!DOCTYPE html>
<html lang="en">

<head>

    <?php $this->load->view("template/head.php") ?>

</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <?php $this->load->view("template/sidebar.php") ?>

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <?php // $this->load->view("template/breadcrumb.php") 
                ?>

                <?php $this->load->view("template/navbar.php") ?>
                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <?php //$this->load->view("admin/_partials/breadcrumb.php") 
                    ?>

                    <?php //if ($this->session->flashdata('success')) : 
                    ?>
                    <!-- <div class="alert alert-success" role="alert"> -->
                    <?php //echo $this->session->flashdata('success'); 
                    ?>
                    <!-- </div> -->
                    <?php //endif; 
                    ?>

                    <div class="card mb-3">
                        <div class="card-header">
                            <a href="<?php echo site_url('Matkul_controller') ?>"><i class="fas fa-arrow-left"></i> Back</a>
                        </div>
                        <div class="card-body">

                            <form action="<?php echo site_url('Matkul_controller/updateMatkul') ?>" method="post" enctype="multipart/form-data">
                                <input class="form-control <?php echo form_error('id_matkul') ? 'is-invalid' : '' ?>" type="hidden" name="id_matkul" placeholder="id matkul" readonly value="<?php echo $data->id_matkul ?>" />

                                <div class="form-group">
                                    <label for="name">Nama Matakuliah</label>
                                    <input class="form-control <?php echo form_error('nama_matkul') ? 'is-invalid' : '' ?>" type="text" name="nama_matkul" placeholder="nama matakuliah" required value="<?php echo $data->nama_matkul ?>" />
                                    <div class="invalid-feedback">
                                        <?php echo form_error('nama_matkul') ?>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="name">Jumlah SKS</label>
                                    <select class="form-control" name="sks" id="sks">
                                        <option selected><?php echo $data->sks; ?> </option>
                                        <?php
                                        $sks = array('0', '1', '2', '3', '4');
                                        if ($sks != null) {

                                            foreach ($sks as $data3) { ?>
                                                <option value="<?php echo $data3 ?>"><?php echo $data3 ?></option>
                                        <?php }
                                        } else {
                                            echo "data i null";
                                        } ?>
                                    </select>
                                    <div class="invalid-feedback">
                                        <?php echo form_error('sks') ?>
                                    </div>
                                </div>

                                <input class="btn btn-success" type="submit" name="btn" value="Save" />
                            </form>

                        </div>

                    </div>
                    <!-- /.container-fluid -->

                </div>
                <!-- End of Main Content -->

                <!-- Footer -->
                <?php $this->load->view("template/footer.php") ?>
                <!-- End of Footer -->

            </div>
            <!-- End of Content Wrapper -->

        </div>
        <!-- End of Page Wrapper -->

        <!-- Scroll to Top Button-->
        <?php $this->load->view("template/scrolltop.php") ?>

        <!-- Logout Modal-->
        <?php $this->load->view("template/modal.php") ?>

        <?php $this->load->view("template/js.php") ?>
</body>

</html>