<?php
header('Content-Type: text/xml');
if ($data != null) {

    $jumField = mysqli_num_fields($data);

    echo "<?xml version='1.0'?>";
    echo "<data>";
    while ($d = mysqli_fetch_array($data)) {
        echo "<matkul>";
        echo "<nama_matkul>", $d['nama_matkul'], "</nama_matkul>";
        echo "<nama_dosen>", $d['nama_dosen'], "</nama_dosen>";
        echo "<kelas>", $d['kelas'], "</kelas>";
        echo "<link_wa>", $d['link_wa'], "</link_wa>";
        echo "<link_clashroom>", $d['link_clashroom'], "</link_clashroom>";
        echo "<niy>", $d['niy'], "</niy>";
        echo "<id_matkul>", $d['id_matkul'], "</id_matkul>";
        echo "</matkul>";
    }
    echo "</data>";
} else {
    echo "Tidak Ada Data";
}
