<!DOCTYPE html>
<html lang="en">

<head>

    <?php $this->load->view("template/head.php") ?>

</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <?php $this->load->view("template/sidebar.php") ?>

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <?php // $this->load->view("template/breadcrumb.php") 
                ?>

                <?php $this->load->view("template/navbar.php") ?>
                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <div class="container">
                        <div class="d-sm-flex align-items-center justify-content-between mb-4">
                            <h1 class="h3 mb-0 text-gray-800">Link WA Group dan Clashroom Praktikum</h1>
                            <!-- <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-download fa-sm text-white-50"></i> Generate Report</a> -->
                        </div>
                        <div class="text-left">
                            <p><a href="<?php echo base_url('Link_controller/addLinkPraktikumView') ?>" class="btn btn-primary">Tambah Link Praktikum</a></p>
                        </div>
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <td><b>No</td>
                                    <td><b>Nama Praktikum</td>
                                    <td><b>Slot</td>
                                    <td><b>Link WhatsApp</td>
                                    <td><b>Link Classroom</td>
                                    <td class="text-center"><b>| Aksi</td>
                                </tr>
                            </thead>
                            <?php
                            if ($data != null) {
                                $count = 0;
                                foreach ($data as $d) :
                                    $count++;
                            ?>
                                    <tr>
                                        <td><?php echo $count ?></td>
                                        <td><?php echo $d->nama_praktikum ?></td>
                                        <td><?php echo $d->slot ?></td>
                                        <td class="text-center"><a href="<?php echo $d->link_wa ?>" class="btn btn-success">WhatsApp</a></td>
                                        <td class="text-center"><a href="<?php echo $d->link_clashroom ?>" class="btn btn-primary">Classroom</a></td>
                                        <td class="text-center"><a href="<?php echo base_url('Link_controller/updateLinkPraktikumView') ?>/<?php echo $d->id_link ?> " class="btn btn-primary">Update</a> | <a class="btn btn-danger" href="<?php echo base_url('Link_controller/deleteLink_Praktikum/') . $d->id_link ?>" onclick="return confirm('Anda ingin menghapus ?')">Delete</a></td>
                                    </tr>
                                <?php endforeach;
                            } else { ?>
                                <tr>
                                    <td colspan="6" align="center">--- Tidak ada data ---</td>
                                </tr>
                            <?php } ?>
                        </table>
                    </div>
                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <?php $this->load->view("template/footer.php") ?>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <?php $this->load->view("template/scrolltop.php") ?>

    <!-- Logout Modal-->
    <?php $this->load->view("template/modal.php") ?>

    <?php $this->load->view("template/js.php") ?>
</body>

</html>