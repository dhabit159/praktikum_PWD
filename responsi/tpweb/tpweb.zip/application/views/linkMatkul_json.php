<?php
if ($data != null) {
    // var_dump($data);
    // die;
    // $count = 1;
    $response = array();
    // $response["data"] = array();
    foreach ($data as $d) :
        // $count++;
        $h['nama_matkul'] = $d->nama_matkul;
        $h['nama_dosen'] = $d->nama_dosen;
        $h['kelas']  = $d->kelas;
        $h['link_wa'] = $d->link_wa;
        $h['link_clashroom'] = $d->link_clashroom;
        $h['niy'] = $d->niy;
        $h['id_matkul'] = $d->id_matkul;
        array_push($response, $h);
    endforeach;

    echo json_encode($response, JSON_PRETTY_PRINT);
} else { ?>
    <tr>
        <td colspan="9" align="center">--- Tidak ada data ---</td>
    </tr>
<?php } ?>